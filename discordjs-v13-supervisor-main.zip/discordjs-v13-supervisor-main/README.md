# v13 Discord Süpervizör Bot Altyapısı Hakkında Bilgiler!

Discord sunucularınızda kullanmanız için kodlanmış " v13 Süpervizör " ( Kayıt / Register + Genel Moderasyon / Moderation ) bot'u projesidir.

# Botun Komutları!

Boş.

# Botun Özellikleri!

Boş.

# Neden v13 Süpervizör ?

Boş.

# İletişim!

● Discord: BoranGkdn0001

● Discord Sunucum: https://discord.gg/borangkdn

● YouTube: https://youtube.com/c/BoranGkdn

● Instagram: https://instagram.com/borangkdn

● Twitter: https://twitter.com/borangkdn
