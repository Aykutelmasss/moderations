module.exports = async function(info) {
    console.log(info)
}

module.exports.conf = {
    name: "warn"
}
