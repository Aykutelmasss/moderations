module.exports = async function(e) {
    console.log(e)
}

module.exports.conf = {
    name: "error"
}
